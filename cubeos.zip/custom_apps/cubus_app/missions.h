#ifndef __APPS_CUSTOM_APPS_CUBUS_APP_MISSIONS_H
#define __APPS_CUSTOM_APPS_CUBUS_APP_MISSIONS_H

int x;
void testing();
void testing2();
#endif
