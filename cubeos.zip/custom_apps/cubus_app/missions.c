#include "missions.h"

void testing(){
    printf("Testing passed\n");
}

void testing2(){
    print("testing 2 called here \n");
}