#include "test.h"

void increment(){
    x++;
    printf("The value of x is %d\n",x);
}