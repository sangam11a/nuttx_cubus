#include "test2.h"
#include "stdio.h"
void increment2(){
    p23++;
    printf("*************************Printing increment2*  %d**********\n",p23);
}