#ifndef __CUSTOM_APPS_CUSTOM_HELLO_TEST_H
#define __CUSTOM_APPS_CUSTOM_HELLO_TEST_H

static int x;
void increment();
#endif