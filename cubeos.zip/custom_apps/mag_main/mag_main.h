
#ifndef __CUSTOM_APPS_MAG_MAIN_H
#define __CUSTOM_APPS_MAG_MAIN_H

#include <uORB/uORB.h>
#include <sched.h>
#include <errno.h>
#include <unistd.h>
#include <time.h>
#include <poll.h>
#include <sensor/mag.h>
#include <nuttx/sensors/sensor.h>


#endif //__CUSTOM_APPS_MAG_MAIN_H
